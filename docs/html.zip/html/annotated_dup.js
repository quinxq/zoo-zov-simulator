var annotated_dup =
[
    [ "Animal", "class_animal.html", "class_animal" ],
    [ "Enclosure", "class_enclosure.html", "class_enclosure" ],
    [ "Loan", "class_loan.html", "class_loan" ],
    [ "Worker", "class_worker.html", "class_worker" ],
    [ "Zoo", "class_zoo.html", "class_zoo" ]
];