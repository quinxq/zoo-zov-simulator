var searchData=
[
  ['carnivore_0',['CARNIVORE',['../zoo__simulator_8cpp.html#a6f4aee1c6d261958dbe9554417a936dbacb3088fa4f9df1b3177493000e8aa40e',1,'zoo_simulator.cpp']]],
  ['cleaner_1',['CLEANER',['../zoo__simulator_8cpp.html#ad7262f5084c25e6b508b4cb1c0eff9afa4fd27a4e074fa185b2f72ec83ead61c3',1,'zoo_simulator.cpp']]]
];
