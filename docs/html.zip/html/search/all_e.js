var searchData=
[
  ['setdaysassigned_0',['setDaysAssigned',['../class_worker.html#aec7a625e9d3fc6382ad454e8d48d8b18',1,'Worker']]],
  ['setdisplayname_1',['setDisplayName',['../class_animal.html#ade2d49285884effc3e7ed546625a16a0',1,'Animal']]],
  ['setenclosureid_2',['setEnclosureId',['../class_animal.html#ac4009865824807ab12ae426031ef3d97',1,'Animal']]],
  ['setsick_3',['setSick',['../class_animal.html#aca8e3ff50ed36e9a08928a992d68f754',1,'Animal']]]
];
