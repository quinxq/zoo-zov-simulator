var searchData=
[
  ['operator_2b_0',['operator+',['../class_animal.html#a4990159a73ca3c5808b1901bae129d50',1,'Animal']]]
];
