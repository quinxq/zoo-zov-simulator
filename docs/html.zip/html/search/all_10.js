var searchData=
[
  ['updateanimal_0',['updateAnimal',['../class_enclosure.html#a004e3cdf772ddc73155ef89b5aca52df',1,'Enclosure']]]
];
