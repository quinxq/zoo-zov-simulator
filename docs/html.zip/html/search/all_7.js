var searchData=
[
  ['incrementagedays_0',['incrementAgeDays',['../class_animal.html#af167d46b39b3251b1f7f5ac65ad41cae',1,'Animal']]],
  ['incrementdayssincepurchase_1',['incrementDaysSincePurchase',['../class_animal.html#ac41b7781db21b068105dfcb07429f4c4',1,'Animal']]],
  ['incrementdaysworked_2',['incrementDaysWorked',['../class_worker.html#af8bd7ae30fbb5d243476ccd12e63f70f',1,'Worker']]]
];
