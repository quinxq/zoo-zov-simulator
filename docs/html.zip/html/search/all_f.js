var searchData=
[
  ['temperate_0',['TEMPERATE',['../zoo__simulator_8cpp.html#adc9fee6ad7fde07167b697ab6984f5d5ad5938597ebb26919bd3b131a5f076b35',1,'zoo_simulator.cpp']]],
  ['tropical_1',['TROPICAL',['../zoo__simulator_8cpp.html#adc9fee6ad7fde07167b697ab6984f5d5ab2ef5f527a20dd2b0b0c4642685e1d1d',1,'zoo_simulator.cpp']]]
];
