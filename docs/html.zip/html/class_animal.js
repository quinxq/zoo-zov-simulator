var class_animal =
[
    [ "Animal", "class_animal.html#a8cf59c1945de48849d150d4dc0ff9211", null ],
    [ "getAgeDays", "class_animal.html#a1ec8ff22881520d9e661771c7d5a27bb", null ],
    [ "getDaysSincePurchase", "class_animal.html#a25d2b178aed9fb68faff00f0c6f0d7f6", null ],
    [ "getDisplayName", "class_animal.html#a0aa118222f52435e3037a387b2cf84c5", null ],
    [ "getEnclosureId", "class_animal.html#a8134a6ea652907e3e4c3978ed1ac196a", null ],
    [ "getGender", "class_animal.html#a46598f491b0c4066817e375b83a8c11b", null ],
    [ "getIsBornInZoo", "class_animal.html#a2af1742d4fe8837b464fba4668f79ec4", null ],
    [ "getIsSick", "class_animal.html#aef7015e5517c0f9b3492e46873f9ff2b", null ],
    [ "getParents", "class_animal.html#a56b6fb60a430377ae5a0124ca5a9a2ec", null ],
    [ "getPreferredClimate", "class_animal.html#a10c9968e3dfc4ffff5545bc4109ed238", null ],
    [ "getPrice", "class_animal.html#afe1cdea6a91a0b1af210713cc1be14f3", null ],
    [ "getSpecies", "class_animal.html#af2d450722b70b6713e724609aff39a8b", null ],
    [ "getType", "class_animal.html#a34d4028e12055ebde6047aa81e3b9f30", null ],
    [ "getUniqueId", "class_animal.html#adf3fcf8bc85625c432dad60def75adab", null ],
    [ "getWeight", "class_animal.html#a96ab6e5e6327b44568fd900e422d2149", null ],
    [ "incrementAgeDays", "class_animal.html#af167d46b39b3251b1f7f5ac65ad41cae", null ],
    [ "incrementDaysSincePurchase", "class_animal.html#ac41b7781db21b068105dfcb07429f4c4", null ],
    [ "operator+", "class_animal.html#a4990159a73ca3c5808b1901bae129d50", null ],
    [ "setDisplayName", "class_animal.html#ade2d49285884effc3e7ed546625a16a0", null ],
    [ "setEnclosureId", "class_animal.html#ac4009865824807ab12ae426031ef3d97", null ],
    [ "setSick", "class_animal.html#aca8e3ff50ed36e9a08928a992d68f754", null ]
];