var class_worker =
[
    [ "Worker", "class_worker.html#adf92ddb1106aeae8c1899390d44f01fc", null ],
    [ "assignEnclosure", "class_worker.html#a2a95f0b6bc8a32fcb9417c085eb11ea6", null ],
    [ "clearAssignedEnclosures", "class_worker.html#aff3f5e37c460cb1e8a35bbd3845b97e5", null ],
    [ "decrementDaysAssigned", "class_worker.html#aea58c0224aeb4c55d3ac3e2dc56f7ea1", null ],
    [ "getAssignedEnclosures", "class_worker.html#a8f138f8816d980b7d833c8050c092aca", null ],
    [ "getDaysAssigned", "class_worker.html#ac78e8fa2c234546280b147fc6e80e4f0", null ],
    [ "getDaysWorked", "class_worker.html#ac50dd0da660fa9bf6703960513c57b93", null ],
    [ "getMaxAnimals", "class_worker.html#a8e155ffe50e0f1fd4537d1b59967274e", null ],
    [ "getName", "class_worker.html#aaaa5808dae61a91b5344224b0ec4d0aa", null ],
    [ "getSalary", "class_worker.html#ac9df2f261f10af65808ae1e23357f45e", null ],
    [ "getType", "class_worker.html#a095472dfddebb31d668d7a8e7910ae78", null ],
    [ "getTypeString", "class_worker.html#adf13d9650b54e36b64df7927013f3ae2", null ],
    [ "incrementDaysWorked", "class_worker.html#af8bd7ae30fbb5d243476ccd12e63f70f", null ],
    [ "setDaysAssigned", "class_worker.html#aec7a625e9d3fc6382ad454e8d48d8b18", null ]
];