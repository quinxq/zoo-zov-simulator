var class_enclosure =
[
    [ "Enclosure", "class_enclosure.html#ade950965a62a016b281eb9a3edb9e8c3", null ],
    [ "addAnimal", "class_enclosure.html#a175957997d42de7a13623c86a917c37c", null ],
    [ "canAddAnimal", "class_enclosure.html#a74290fb7ae670829e39a988ce3c9c644", null ],
    [ "getAnimalCount", "class_enclosure.html#ad20086c6e0c646359549ead9a5676d4d", null ],
    [ "getAnimals", "class_enclosure.html#a826e6bfb0bbadfb38023d75e31e6be85", null ],
    [ "getAnimalType", "class_enclosure.html#a769df76d0e3f84bb9378ff6d3b65a582", null ],
    [ "getCapacity", "class_enclosure.html#a4ee9f07a4fa59a4373af66312ad2669c", null ],
    [ "getClimate", "class_enclosure.html#aaefd298041c3b3e43c1ef408bc554a27", null ],
    [ "getDailyCost", "class_enclosure.html#a2397c5986a3fc3758ec1e620c707d3c4", null ],
    [ "getId", "class_enclosure.html#af04d49ecd83669ded1ba2d880f68ba1d", null ],
    [ "removeAnimal", "class_enclosure.html#a5c508cf252e48a10f8085be456b9d5aa", null ],
    [ "updateAnimal", "class_enclosure.html#a004e3cdf772ddc73155ef89b5aca52df", null ]
];