var class_loan =
[
    [ "Loan", "class_loan.html#a7f1930660bec6db1def695c538febd8e", null ],
    [ "getRemainingDebt", "class_loan.html#a2074ae4a67957f0958934d0957b5011a", null ],
    [ "dailyInterestRate", "class_loan.html#aac28397732a5adcc1026e126b5dc5ed9", null ],
    [ "dailyRepayment", "class_loan.html#aa2ff5695ab5568a771780ca28b8efe33", null ],
    [ "days", "class_loan.html#a85e618993b988e1615d5483274d52a50", null ],
    [ "daysLeft", "class_loan.html#a161b0bcf803b8a8b7e7ff5155ef1db7c", null ],
    [ "principal", "class_loan.html#a9aa84abcaecb63fe6d16e256479e4f61", null ]
];